package sena.ejercicio3;

import java.util.Scanner;
        
public class Ejercicio3 {
    static Scanner dato = new Scanner(System.in);

    public static void main(String[] args) {
        String Con;
        System.out.println("ingrese su password que contiene 2 numeros y 2 letras en este orden");
        Con= dato.nextLine();
        while(!Con.equals("24ya")){
            System.out.println("password incorrecta");
             System.out.println("ingrese su password que contiene 2 numeros y 2 letras en este orden");
        Con= dato.nextLine();
            
        }
    }
}