/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package sena.ejercicio2;

import java.util.Scanner;

public class Ejercicio2 {
    static Scanner dato = new Scanner(System.in);

    public static void main(String[] args) {
        float N,Pr,Sum= 0;
        int x= 0;
        System.out.println("ingrese su nota la cual va desde 0 hasta 5,0");
        N= dato.nextFloat();
        while(N>0){
        x= (x+1);
        Sum= (Sum+N);
        System.out.println("tu numero es "+N);
         System.out.println("ingrese su nota la cual va desde 0 hasta 5,0");
         N= dato.nextFloat();
    }
    Pr= (Sum/x);
    System.out.println("su promedio es " +Pr);
    }
} 

