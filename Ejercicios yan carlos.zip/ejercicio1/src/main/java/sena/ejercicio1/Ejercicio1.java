/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package sena.ejercicio1;

import java.util.Scanner;
        
public class Ejercicio1 {
    static Scanner dato = new Scanner(System.in);

    public static void main(String[] args) {
        int Con;
        System.out.println("ingrese su password que contiene 4 numeros");
        Con= dato.nextInt();
        while(Con!=2423){
            System.out.println("password incorrecta");
             System.out.println("ingrese su password que contiene 4 numeros");
        Con= dato.nextInt();
            
        }
    }
}
