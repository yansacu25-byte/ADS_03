package sena.ejercicio4;
import java.util.Scanner;

public class Ejercicio4 {
static Scanner dato = new Scanner(System.in);

    public static void main(String[] args) {
        int w,x=1;
        System.out.println("ingrese un numero positivo");
        w= dato.nextInt();
        while(w>1){
            x=x *w;
            
            System.out.println("calculando "+x );
         w=w-1;
            
        }
        
    }
}
