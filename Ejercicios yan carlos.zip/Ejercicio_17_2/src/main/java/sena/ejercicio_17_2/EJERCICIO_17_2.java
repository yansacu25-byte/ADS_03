/*Un hospital necesita procesar las consultas de pacientes. Por cada paciente 
se ingresan: número de historia clínica, edad, sexo y tipo de consulta 
(urgencia, control, general). El proceso termina cuando se ingrese un número 
de historia clínica igual a -1. Al finalizar, mostrar cuántas consultas fueron 
urgencias, controles y generales.*/
package sena.ejercicio_17_2;
import java.util.Scanner;
public class EJERCICIO_17_2 {
static Scanner dato = new Scanner(System.in);
    public static void main(String[] args) {
        int Cont=0, Urg=0, Gen=0;
        System.out.println("Ingrese el numero de la historia clinica del paciente");
        int Hclp= dato.nextInt();
        System.out.println("Ingrese la edad del paciente");
        int Edad= dato.nextInt();
        System.out.println("Ingrese el sexo del paciente");
        dato.nextLine();
        String Sexo= dato.nextLine();
        System.out.println("seleccione tipo de consulta\n1: urgencia\n2: control\n3: general");
        int Tc= dato.nextInt();
        switch (Tc){
            case 1:
                System.out.println("seleccione control");
                 Cont=Cont++;
                break;
            case 2:  
                System.out.println("seleccione urgencia");
                 Urg=Urg++; 
                 break;
            case 3:
                System.out.println("seleccione general");
                 Gen=Gen++;
                 break;
            default:
                System.out.println("Opcion incorrecta");
                    while (Hclp !=-1){
                      System.out.println("Ingrese el numero de la historia clinica del paciente");
                      Hclp= dato.nextInt();
                      System.out.println("Ingrese la edad del paciente");
                      Edad= dato.nextInt();
                      System.out.println("Ingrese el sexo del paciente");
                      Sexo= dato.nextLine();
                      System.out.println("seleccione tipo de consulta\n1: urgencia\n2: control\n3: general");
                      Tc= dato.nextInt();
                      switch (Tc){
                           case 1:
                               System.out.println("selecciono control");
                               Cont=Cont++;
                                 break;
                            case 2:  
                                System.out.println("selecciono urgencia");
                                Urg=Urg++;
                                break;
                            case 3:
                                 System.out.println("selecciono general");
                                 Gen=Gen++;
                                 break;
                            default:
                                 System.out.println("Opcion incorrecta");
                                 
                      }
                    }
        
                    System.out.println("El total de paciente en consulta general es de "+Gen);
                    System.out.println("El total de paciente en consulta control es de "+Cont);
                    System.out.println("El total de paciente en consulta urgencias es de "+Urg);
                    
        }
    }
}