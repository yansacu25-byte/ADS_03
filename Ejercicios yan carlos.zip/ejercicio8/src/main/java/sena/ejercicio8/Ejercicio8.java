package sena.ejercicio8;
import java.util.Scanner;
public class Ejercicio8 {
static Scanner dato = new Scanner(System.in);
    public static void main(String[] args) {
        int Edad;
        float sub = 50,Tps = 0;
        String Estudia;
        System.out.println("Por favor ingrese su edad");
        Edad=dato.nextInt();
        dato.nextLine();
        System.out.println("Usted estudia? si o no");
        Estudia =dato.nextLine();
        if ((Edad < 25&& Estudia.equals("si"))){
           Tps = (float) (sub +(sub*0.50)); 
            System.out.println("El total de su subsidio es "+Tps);
        } else {
            if (Edad < 25 && Estudia.equals("no")) {
              Tps=sub;
              System.out.println("El total de su subsidoo es "+Tps);
              } else {
                        if (Edad >= 25 || !Estudia.equals("si")) 
                        Tps = (float) (sub +(sub*0.10));
                System.out.println("El total de su subsidio es "+Tps);
            dato.hasNextLine();
                    if (Edad >= 25 && Estudia.equals("no"))
            System.out.println("no tiene derecho a subsidio ");
            }
        }
    }
}