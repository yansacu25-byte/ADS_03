/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package sena.banco_nequi;

/**
 *
 * @author usuario
 */
public class Banco_nequi {

    public static void main(String[] args) {
        Cajero_nequi1 ejer = new Cajero_nequi1();
        ejer.Cajero_nequi();
}
}
