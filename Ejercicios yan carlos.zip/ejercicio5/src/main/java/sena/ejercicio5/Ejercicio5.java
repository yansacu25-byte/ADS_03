/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package sena.ejercicio5;

import java.util.Scanner;

public class Ejercicio5 {

    static Scanner dato = new Scanner(System.in);

    public static void main(String[] args) {
        String M;
        float v, VT, NP = 0;
        System.out.println("ingrese el producto que comprado");
        M=dato.nextLine();
        System.out.println("Ingrese el valor del producto");
        v = dato.nextFloat();
        while (!M.equals("fin")) {
            NP = (NP + v);
            M= dato.nextLine();
            System.out.println("ingrese el otro producto");
            dato.nextLine();
            System.out.println("Ingrese el valor del producto ");
            v = dato.nextFloat();
        }
        VT = (NP + v);
        System.out.println("El total de su compra es " + VT);
    }

}
