/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sena.banco_nequi;

import javax.swing.JOptionPane;
import java.util.Random;

public class Cajero_nequi1 {

    private int Saldo = 7000000, SaldoCN = 20000000, retiroD = 2100000;
    private boolean continuar = true;

    public Cajero_nequi1() {
    }

    public int getSaldo() {
        return Saldo;
    }

    public void setSaldo(int Saldo) {
        this.Saldo = Saldo;
    }

    public int getSaldoCN() {
        return SaldoCN;
    }

    public void setSaldoCN(int SaldoCN) {
        this.SaldoCN = SaldoCN;
    }

    public int getRetiroD() {
        return retiroD;
    }

    public void setRetiroD(int retiroD) {
        this.retiroD = retiroD;
    }

    public void Cajero_nequi() {
        while (continuar) {
            try {
                StringBuilder menu = new StringBuilder("MENU CAJERO AUTOMATICO \n\n");
                menu.append("seleciones una opcion del 1 al 4 asi \n")
                        .append("1. consultar saldo \n")
                        .append("2. consignar dinero \n")
                        .append("3. retirar dinero \n")
                        .append("4. salir \n");
                String opcion = JOptionPane.showInputDialog(null, menu, "Cajero Automatico", JOptionPane.QUESTION_MESSAGE);
                if (opcion == null) {
                    if (confirmarSalida()) {
                        continuar = false;
                    }
                    continue;
                }
                int opc = Integer.parseInt(opcion);
                switch (opc) {
                    case 1:
                        consulta_saldo();
                        break;
                    case 2:
                        consignar_dinero();
                        break;
                    default:
                        throw new AssertionError();
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error", "Debes ingresar un numero del 1 al 4", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public boolean confirmarSalida() {
        int confirmar = JOptionPane.showConfirmDialog(null, "¿Estas seguro que deseas salir?", "confirmar Salida", JOptionPane.YES_NO_OPTION);
        return confirmar == JOptionPane.YES_OPTION;
    }

    public String id_validacion() {
        Random id = new Random();
        int numero = id.nextInt(9000) + 1000;
        return "ID de la operacion # " + numero + "\n";
    }

    public void consulta_saldo() {
        String validacion = id_validacion();
        StringBuilder mensaje1 = new StringBuilder("CONSULTAR SALDO \n");
        mensaje1.append(validacion)
                .append("Saldo Actual: $")
                .append(String.format("%,d", Saldo));
        JOptionPane.showInternalMessageDialog(null, mensaje1, "Consultar Saldo", JOptionPane.INFORMATION_MESSAGE);
    }

    public void consignar_dinero() {
        try {
            String consigna = id_validacion();

            JOptionPane.showMessageDialog(null, "ADVERTENCIA: El cajero no recibe monedas ", "Recuerde que no se reciben billetes menores a 20.000$ ", JOptionPane.WARNING_MESSAGE);
            String Ds = JOptionPane.showInputDialog(null, "Ingrese la cantidad a consignar ", "CONSIGNAR DINERO", JOptionPane.INFORMATION_MESSAGE);
            int D = Integer.parseInt(Ds);

            if (D >= 20000) {
                Saldo += D;

            } else {
                JOptionPane.showMessageDialog(null, "el valor que intenta ingresar no es correcto");
            }
            StringBuilder mensaje2 = new StringBuilder("CONSIGNAR DINERO \n");
            mensaje2.append(consigna)
                    .append("Saldo Actual: $")
                    .append(String.format("%,d", Saldo));
            JOptionPane.showInternalMessageDialog(null, mensaje2, " Consignar dinero", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Debes ingresar solo numero", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }
}
