package sena.ejecicio6;
import java.util.Scanner;
public class Ejecicio6 {
 static Scanner dato = new Scanner(System.in);

    public static void main(String[] args) {
        float N,Dt,Con= 0;
        int x= 0;
        System.out.println("ingrese el valor que va a depositar");
        N= dato.nextFloat();
        while(N>0){
        x= (x+1);
        Con= (Con+N);
        System.out.println("su deposito fue "+N);
         System.out.println("ingrese el valor que va a depositar");
         N= dato.nextFloat();
    }
    Dt= (Con+x);
    System.out.println("el total consiganado es de " +Dt);
    }
} 
